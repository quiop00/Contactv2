package com.example.contactv1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
    }
}
