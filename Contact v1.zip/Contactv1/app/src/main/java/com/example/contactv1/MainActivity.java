package com.example.contactv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton floatingActionButton;
    ListView lvContact;
    EditText edtSearch;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void init(){
        floatingActionButton=(FloatingActionButton)findViewById(R.id.btn_add_contact);
        lvContact=(ListView) findViewById(R.id.lv_contact);
        edtSearch=(EditText)findViewById(R.id.edt_search);
    }
}
